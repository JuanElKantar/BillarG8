from flask import Blueprint, render_template, request, redirect, session

login_bp = Blueprint('login', __name__)

@login_bp.route('/login', methods=['POST'])
def login():
    from user import login_handler
    # Procesar el inicio de sesión utilizando la función login_handler del archivo user.py
    # ... (código para procesar el inicio de sesión)