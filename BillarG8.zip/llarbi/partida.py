from flask import Blueprint, render_template, request

partida_bp = Blueprint('partida', __name__)

@partida_bp.route('/partida', methods=['GET', 'POST'])
def create_partida():
    if request.method == 'POST':
        # Procesar los datos del formulario y crear una partida
        game_mode = request.form["GameMode"]
        num_players = request.form["Players"]
        GameTime = request.form["GameTime"]
        # ... (código para crear partida)

        return "Partida creada correctamente"

    # Renderizar el formulario de partida
    return render_template('partida.html')