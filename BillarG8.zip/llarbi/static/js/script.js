let contadorL = document.getElementById("plocal");
let sumaL = 0;
let contadorV = document.getElementById("pvis");
let sumaV = 0;
let historialBandera = [];
let historial = [];

function incrementL(puntos){
  sumaL += puntos;
  contadorL.innerText = sumaL;
  historialBandera.push(1);
  historial.push(puntos);
  console.log(historialBandera.length);
}

function incrementV(puntos){
  sumaV += puntos;
  contadorV.innerText = sumaV;
  historialBandera.push(0);
  historial.push(puntos);
  console.log(historialBandera.length);
}

function newgame(){
  sumaL = 0;
  sumaV = 0;
  historialBandera = [];
  historial = [];
  contadorV.innerText = sumaL;
  contadorL.innerText = sumaV;
}

function undo(){
  if (historialBandera[historialBandera.length - 1] === 1){
    sumaL -= historial[historial.length - 1];
    historialBandera.pop();
    historial.pop();
    contadorL.innerText = sumaL;
  } else if (historialBandera[historialBandera.length - 1] === 0){
    sumaV -= historial[historial.length - 1];
    historialBandera.pop();
    historial.pop();
    contadorV.innerText = sumaV;
  }
}

var startTime = 0;
var timerInterval;

function updateTimer() {
  var elapsedTime = Math.floor((Date.now() - startTime) / 1000);
  var minutes = Math.floor(elapsedTime / 60);
  var seconds = elapsedTime % 60;
  var formattedTime = padNumber(minutes) + ":" + padNumber(seconds);
  document.getElementById("timer").textContent = formattedTime;
}

function padNumber(number) {
  return number.toString().padStart(2, "0");
}

function startGame() {
  startTime = Date.now();
  timerInterval = setInterval(updateTimer, 1000);
}

function endGame() {
  clearInterval(timerInterval);
}

document.addEventListener("DOMContentLoaded", function() {
  startGame();
});

// Event listener for game end (for testing purposes)
document.getElementById("end-game-btn").addEventListener("click", function() {
  endGame();
});







// Obtener el elemento del contador
var contadorElemento = document.getElementById('contador');

// Establecer la fecha y hora de destino (puedes ajustarla a tu preferencia)
var fechaObjetivo = new Date('2023-06-01T00:00:00Z').getTime();

// Actualizar el contador cada segundo
var intervalo = setInterval(function() {
  // Obtener la fecha y hora actual
  var fechaActual = new Date().getTime();

  // Calcular la diferencia entre la fecha actual y la fecha objetivo
  var diferencia = fechaObjetivo - fechaActual;

  // Verificar si se alcanzó la fecha objetivo
  if (diferencia <= 0) {
    clearInterval(intervalo);
    contadorElemento.textContent = '¡Tiempo alcanzado!';
    return;
  }

  // Calcular los días, horas, minutos y segundos restantes
  var segundos = Math.floor(diferencia / 1000) % 60;
  var minutos = Math.floor(diferencia / (1000 * 60)) % 60;
  var horas = Math.floor(diferencia / (1000 * 60 * 60)) % 24;
  var dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));

  // Mostrar el contador en el elemento correspondiente
  contadorElemento.textContent = 'Tiempo restante: ' + dias + ' días, ' + horas + ' horas, ' + minutos + ' minutos, ' + segundos + ' segundos';
}, 1000);